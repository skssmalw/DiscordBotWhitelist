const { SlashCommandBuilder } = require('@discordjs/builders');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const config = require('./config.json');

const commands = [
  new SlashCommandBuilder().setName('whitelist').setDescription('Whitelist a user').addUserOption(option => option.setName('user').setDescription('The user to whitelist').setRequired(true)),
  new SlashCommandBuilder().setName('unwhitelist').setDescription('Unwhitelist a user').addUserOption(option => option.setName('user').setDescription('The user to unwhitelist').setRequired(true))
]
  .map(command => command.toJSON());

const rest = new REST({ version: '9' }).setToken(config.token);

(async () => {
  try {
    console.log('Started refreshing application (/) commands.');

    await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), {
      body: commands,
    });

    console.log('Successfully reloaded application (/) commands.');
  } catch (error) {
    console.error(error);
  }
})();