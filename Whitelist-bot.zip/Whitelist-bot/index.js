const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const { token, clientId, guildId, adminUserIds, whitelistFile, logChannelId } = require('./config.json');
const fs = require('fs');

// Initialize the bot client
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

// Load whitelist from JSON file
let whitelist = [];
if (fs.existsSync(whitelistFile)) {
    whitelist = JSON.parse(fs.readFileSync(whitelistFile));
}

// Function to log actions
const logAction = async (message) => {
    const logChannel = await client.channels.fetch(logChannelId);
    if (logChannel) {
        logChannel.send(message);
    } else {
        console.error("Log channel not found!");
    }
};

// Register the slash commands once, only on bot startup
const { SlashCommandBuilder } = require('@discordjs/builders');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');

const registerCommands = async () => {
    const commands = [
        new SlashCommandBuilder()
            .setName('whitelist')
            .setDescription('Whitelist a user by Roblox User ID')
            .addStringOption(option =>
                option.setName('user_id')
                    .setDescription('Roblox User ID to whitelist')
                    .setRequired(true)
            ),
        new SlashCommandBuilder()
            .setName('unwhitelist')
            .setDescription('Unwhitelist a user by Roblox User ID')
            .addStringOption(option =>
                option.setName('user_id')
                    .setDescription('Roblox User ID to unwhitelist')
                    .setRequired(true)
            )
    ]
        .map(command => command.toJSON());

    const rest = new REST({ version: '9' }).setToken(token);
    try {
        console.log('Started refreshing application (/) commands.');
        await rest.put(
            Routes.applicationGuildCommands(clientId, guildId),
            { body: commands },
        );
        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
};

// Event when bot is ready
client.once('ready', async () => {
    console.log('Bot is online!');
    await registerCommands(); // Register commands only once after bot is ready
});

// Handle slash command interactions
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isCommand()) return;

    const { commandName, user, options } = interaction;

    // Check if user is an admin
    if (!adminUserIds.includes(user.id)) {
        return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
    }

    if (commandName === 'whitelist') {
        const userId = options.getString('user_id');
        if (!userId) {
            return interaction.reply({ content: 'You need to provide a user ID.', ephemeral: true });
        }

        // Check if the user is already whitelisted
        if (whitelist.includes(userId)) {
            return interaction.reply({ content: `User ID ${userId} is already whitelisted.`, ephemeral: true });
        }

        // Add user ID to whitelist
        whitelist.push(userId);
        fs.writeFileSync(whitelistFile, JSON.stringify(whitelist, null, 2));

        // Create embed for successful whitelisting
        const embed = new EmbedBuilder()
            .setTitle('User Whitelisted Successfully!')
            .setDescription(`User with ID ${userId} has been added to the whitelist.`)
            .setColor('Green')
            .setTimestamp();

        // Log action
        await logAction(`User ${user.username} whitelisted ${userId}`);

        return interaction.reply({ embeds: [embed] });

    } else if (commandName === 'unwhitelist') {
        const userId = options.getString('user_id');
        if (!userId) {
            return interaction.reply({ content: 'You need to provide a user ID.', ephemeral: true });
        }

        // Check if the user is whitelisted
        if (!whitelist.includes(userId)) {
            return interaction.reply({ content: `User ID ${userId} is not whitelisted.`, ephemeral: true });
        }

        // Remove user ID from whitelist
        whitelist = whitelist.filter(id => id !== userId);
        fs.writeFileSync(whitelistFile, JSON.stringify(whitelist, null, 2));

        // Create embed for successful unwhitelisting
        const embed = new EmbedBuilder()
            .setTitle('User Unwhitelisted Successfully!')
            .setDescription(`User with ID ${userId} has been removed from the whitelist.`)
            .setColor('Red')
            .setTimestamp();

        // Log action
        await logAction(`User ${user.username} unwhitelisted ${userId}`);

        return interaction.reply({ embeds: [embed] });
    }
});

// Log in to the bot
client.login(token);